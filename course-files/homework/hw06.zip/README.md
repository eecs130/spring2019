---
layout: default
title: Homework 06
nav_exclude: True
---

# Homework 06 Instructions
Please follow the instructions in the <a href="https://docs.google.com/document/d/1QTsIkQEgE0Bi3y7UCA52dwsN4QKZUT1-aigJPHRJuSs/edit?usp=sharing" target="_blank">Google Doc</a>. The files that are needed for homework 05 can be downloaded [here](../hw05.zip).

## Due
Friday, May 17 at 11:59PM
