const name = "John";

document.write("Welcome, " + name + "! Make yourself comfortable.");
