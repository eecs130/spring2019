const makeBigger = () => {
   alert('make bigger!');
};

const makeSmaller = () => {
   alert('make smaller!');
};

/*
document.querySelector(???).onclick = makeBigger;
document.querySelector(???).onclick = makeSmaller;
*/
