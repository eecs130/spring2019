---
layout: default
title: Lab 08
nav_exclude: True
---

# Lab 08 Instructions
Please complete <a href="https://docs.google.com/document/d/146L0Soe1UUZP1IVH_XJspiA5ocjQQCbNBSFInSQOp2k/edit?usp=sharing" target="_blank">this lab</a>, which we will be starting during class on Wednesday. There are two ways to receive full credit in lab:

### Option 1
Your attendance (and earnest participation) in lab is enough to earn full lab credit.

### Option 2
Completing the lab and submitting a link to your completed lab on GitHub for your TA to grade.
